import { SurfaceSnapshot } from './surface.types';
/**
 * A snapshot rendered for a prompt.
 *
 * Four properties matter more than the layout.
 *
 * **Deterministic** — the same snapshot renders to the same bytes, which is why no
 * relative age is ever computed from a clock: the age below is the distance between
 * two timestamps that are both in the snapshot.
 *
 * **Complete** — every fact the Surface declares is rendered. Nothing is dropped for
 * being judged unimportant: the only omission is the budget's, and it says so. A
 * hand-written salience heuristic would be a second, silent selection on top of the
 * producer's own, and the fact it dropped would be invisible to a model that has no
 * reason to suspect a gap.
 *
 * **Bounded** — the budget is enforced here, in the order §9 prescribes.
 *
 * **Fenced** — every string that could have come from a machine passes through `safe`,
 * because a resource name is data and must never be able to close the fence and start
 * giving instructions (§8.4).
 */
export interface DigestOptions {
    maxBytes?: number;
    maxTextLength?: number;
    /** Off by default: refs are the longest thing on a line and cost every turn, while
     * one call to the full-snapshot tool returns all of them at once. */
    includeResourceRefs?: boolean;
    /** The tail line names the tool a model can call for the whole snapshot. Every host
     * names that tool itself, so the default here is generic and hosts override it. */
    fullSnapshotTool?: string;
}
export interface SurfaceDigest {
    text: string;
    bytes: number;
    truncated: boolean;
    omittedObservations: number;
}
export declare function renderSurfaceDigest(snapshot: SurfaceSnapshot, options?: DigestOptions): SurfaceDigest;
/**
 * Everything that can carry text from a machine passes through here.
 *
 * Newlines are collapsed because a line break is how a value would forge a new section;
 * angle brackets are removed because they are how it would forge the closing fence. The
 * loss is nil for host names, codes, units and package names, and total for an attack.
 */
export declare function safe(value: string, maxLength: number): string;
