import { SurfaceSnapshot } from './surface.types';
export interface SurfaceValidation {
    valid: boolean;
    errors: Array<{
        path: string;
        message: string;
    }>;
}
/** Snapshots arriving over the wire are capped before parsing: the spec asks producers
 * to stay small, and a consumer that only asks nicely has no defence against one that
 * does not (§9). 32 KB is the recommended ceiling. */
export declare const MAX_SNAPSHOT_BYTES = 32768;
/**
 * The schema is the contract, so it is read rather than restated. It lives with the
 * specification and is copied next to the compiled code by the build; in a source
 * checkout only the docs copy exists, hence the two candidates. One file, no drift.
 */
export declare function surfaceSchemaFile(): string;
export declare function validateSurfaceSchema(input: unknown): SurfaceValidation;
/**
 * The one entry point a request handler should use: size, shape, then nothing else.
 *
 * A snapshot that fails is dropped, never rejected — a defect in the Surface must not
 * fail the user's question (§12.1, item 9), so this returns null instead of throwing.
 */
export declare function acceptSurface(input: unknown, maxBytes?: number): {
    snapshot: SurfaceSnapshot | null;
    reason?: string;
};
