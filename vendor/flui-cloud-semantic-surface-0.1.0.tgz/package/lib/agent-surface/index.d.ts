export { ATTENTION_REASONS, SCOPE_KINDS, SURFACE_SCHEMA_VERSION, } from './surface.types';
export type { AttentionTarget, Completeness, EntityReference, EntityRole, Observation, ObservationSource, ScopeState, SemanticScopeSnapshot, SurfaceSnapshot, } from './surface.types';
export { MAX_SNAPSHOT_BYTES, acceptSurface, surfaceSchemaFile, validateSurfaceSchema, } from './surface-validate';
export type { SurfaceValidation } from './surface-validate';
export { isRealInstant, validateSurfaceSemantics } from './surface-semantics';
export type { IssueSeverity, SemanticValidationIssue, SemanticValidationOptions, } from './surface-semantics';
export { renderSurfaceDigest, safe } from './surface-digest';
export type { DigestOptions, SurfaceDigest } from './surface-digest';
