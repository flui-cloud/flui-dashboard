/**
 * Wire format of the Semantic Surface, schema 0.2.
 *
 * The contract is the JSON Schema in docs/agent-surface/, not this file: these types
 * are a convenience for the TypeScript side and MUST stay in step with it. Anything
 * arriving from a browser is validated against the schema before it is treated as a
 * SurfaceSnapshot — the UI is never trusted (spec §8.1).
 */
export declare const SURFACE_SCHEMA_VERSION = "0.2";
export type ObservationSource = 'ui' | 'api' | 'derived';
export type EntityRole = 'primary' | 'selected' | 'related';
export interface EntityReference {
    /** `<namespace>://<entity-type>/<entity-id>`, a single path segment for the id. */
    ref: string;
    label?: string;
    role?: EntityRole;
}
export interface Observation {
    /** Namespaced, or a recognised vocabulary such as the OpenTelemetry conventions. */
    key: string;
    /** What the user saw. The only container for the value — there is no bare `value`. */
    presentedAs: {
        value?: string | number | boolean | null;
        unit?: string;
        text?: string;
    };
    source?: ObservationSource;
    /** When the reading was taken. Absent means the age is UNKNOWN, never `generatedAt`. */
    observedAt?: string;
    resourceRef?: string;
}
export interface ScopeState {
    loading?: boolean;
    error?: boolean;
    /** A namespaced code, never the error text: backend prose is an injection vector. */
    errorCode?: string;
    empty?: boolean;
}
export interface Completeness {
    shown: number;
    total?: number;
    filtered?: boolean;
    truncated?: boolean;
}
export interface SemanticScopeSnapshot {
    /** Identifies an instance, not a definition (spec §4.2). */
    id: string;
    /** Semantic ownership, never render position. */
    parentId?: string;
    kind: string;
    label?: string;
    entities?: EntityReference[];
    observations?: Observation[];
    state?: ScopeState;
    completeness?: Completeness;
    extensions?: Record<string, unknown>;
}
export interface AttentionTarget {
    scopeId: string;
    entityRef?: string;
    reason?: string;
}
export interface SurfaceSnapshot {
    schemaVersion: '0.2';
    app: {
        id: string;
        version?: string;
    };
    surface: {
        id: string;
        route?: string;
        revision: number;
        generatedAt: string;
        locale?: string;
        truncated?: boolean;
    };
    /** Ordered by salience, resolved by the producer. Never competing claims. */
    attention: AttentionTarget[];
    /** Flat; hierarchy via parentId. Array order carries no meaning. */
    scopes: SemanticScopeSnapshot[];
    extensions?: Record<string, unknown>;
}
/** Reserved attention reasons of §6.3, in the default salience order of §4.1. */
export declare const ATTENTION_REASONS: readonly ["manual", "overlay", "selection", "active-view", "route"];
/** Reserved scope kinds of §6.2. */
export declare const SCOPE_KINDS: readonly ["page", "region", "selection", "list", "form", "overlay"];
