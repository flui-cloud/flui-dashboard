import { SurfaceSnapshot } from './surface.types';
/**
 * The second level of validation (spec §12.3).
 *
 * A JSON Schema sees one document's shape and nothing else: it cannot follow a
 * reference to another scope, cannot know the previous snapshot, and cannot tell a
 * well-formed date from a real one. Those checks live here.
 *
 * Three obligations are deliberately absent — inactive scopes, secret redaction and
 * the anti-drift rule are properties of the producer, not of the document, and no
 * artefact can carry their evidence (§12.3.1).
 */
export type IssueSeverity = 'error' | 'warning';
export interface SemanticValidationIssue {
    code: string;
    path: string;
    message: string;
    severity: IssueSeverity;
}
export interface SemanticValidationOptions {
    previousSnapshot?: SurfaceSnapshot;
    maxBytes?: number;
}
export declare function validateSurfaceSemantics(snapshot: SurfaceSnapshot, options?: SemanticValidationOptions): SemanticValidationIssue[];
/**
 * Round-tripping is the check, not `Date.parse`: that accepts out-of-range components
 * on some runtimes and rejects them on others, which would make conformance depend on
 * where the validator happens to run.
 */
export declare function isRealInstant(value: string): boolean;
