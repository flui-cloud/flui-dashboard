# Semantic Surface

> **The Semantic Surface is a serializable, medium-independent representation of the
> user's current attention and of what the interface has actually presented to them.**

It answers exactly one question: **what is the user looking at right now, and what does
"this" refer to?**

An agent that is handed a screenshot has to read pixels. An agent that is handed the
application's database has to guess which row the user meant. A Semantic Surface snapshot
is neither: it is a small, declared, validatable document in which the interface says what
it put in front of the person — the scopes on screen, the entities they name, the readings
they showed, and which of them the user's attention is on.

It deliberately does **not** answer what the current truth of the domain is, which
operations are available, who is authorised to perform them, or how they are executed.
A snapshot is descriptive, never authoritative: every entity in it is a reference to be
resolved through a real tool before anything is acted on.

## Where the examples come from

The Semantic Surface was designed at Flui and first implemented for **vops**, a local-first
tool for provisioning and operating VPS servers. vops is the pilot binding the specification's
Annex A records, and at the time of writing it is the only producer. That shows through every
example, and naming it once here keeps one distinction clear: `vops://host/vmi3399032` is an
entity reference in **one producer's** namespace, `vops.*` observation keys and `flui.canvas`
are **one producer's** extension vocabulary, and the schema's `$id` is a Flui URL because a
schema identifier has to be owned by someone — it identifies the document, it is not a
location the schema is fetched from. None of those strings are part of the contract. What §4
fixes is how a reference and an extension key are *formed*; a second implementation coins its
own scheme and its own namespace and is no less conformant.

## The contract

The contract is the **wire format** — the JSON shape of a snapshot — not any particular
language binding.

- **Normative specification:** [`docs/agent-surface/semantic-surface-core-v0.2.md`](docs/agent-surface/semantic-surface-core-v0.2.md)
- **JSON Schema (draft 2020-12):** [`docs/agent-surface/semantic-surface.schema.json`](docs/agent-surface/semantic-surface.schema.json)

Sections §1–§13 of the specification are normative; Annexes A and B are informative.
The TypeScript interfaces in this package are a convenient rendering of the same contract
and must stay in step with the schema — where they disagree, the schema wins.

One further document is kept for provenance only and is **not normative**: the decision
record answering the technical review of v0.1, in Italian. The two documents behind it — the
v0.1 draft and the review itself — were internal working documents of the sponsoring product
and are not distributed here; the core specification's front matter cites all three.

## What this package provides

A reference implementation of the consumer side, in three layers.

| Layer | Entry point | What it does |
| --- | --- | --- |
| Wire validation | `acceptSurface`, `validateSurfaceSchema` | Caps the payload size, then validates it against the schema. A snapshot that fails is dropped, never thrown on — a defect in the Surface must not fail the user's question. |
| Semantic validation | `validateSurfaceSemantics` | The eleven cross-document checks a JSON Schema cannot make: broken references, cycles, duplicate ids, counts that exceed their totals, timestamps that are well formed but not real instants, inconsistent truncation, revisions that do not advance. |
| Prompt rendering | `renderSurfaceDigest` | Renders a snapshot into a fenced, deterministic, byte-budgeted block. Every string that could have come from a machine passes through `safe`, because a resource name is data and must never be able to close the fence and start giving instructions. |

Producers — the code inside an application that builds a snapshot — are not in this
package. They are written against the schema, in whatever language the interface is
written in.

## Install

Not on a registry, and marked `private` so it cannot reach one by accident. Consume it from a
checkout:

```
git clone <this repository> semantic-surface
cd semantic-surface && npm install
```

then depend on the directory — `"@flui-cloud/semantic-surface": "link:../semantic-surface"`
with pnpm, or `"file:../semantic-surface"` with npm.

`npm install` also builds `lib/`, through `prepare`. That is not a convenience: `lib/` is not
committed and neither protocol runs a lifecycle script in the linked directory, so nothing else
in the chain ever builds this package — and the consumer that skips it fails at its own
`tsc` with an unresolved module, which names the wrong problem.

A consumer that publishes must not carry `link:` or `file:` into its tarball: neither protocol
is rewritten on pack, and an install of that tarball cannot resolve a dependency that is not on
the registry. vops gates that in `scripts/check-local-deps.js`, run from its `prepublishOnly`.

## Use

```ts
import {
  acceptSurface,
  renderSurfaceDigest,
  validateSurfaceSemantics,
} from '@flui-cloud/semantic-surface';

// Anything arriving from a browser is untrusted until it has been through the schema.
const { snapshot, reason } = acceptSurface(request.body.surface);
if (!snapshot) {
  // Drop it and answer the question anyway.
  return answerWithoutSurface(reason);
}

const issues = validateSurfaceSemantics(snapshot);
const warningsOnly = issues.every((issue) => issue.severity === 'warning');

const digest = renderSurfaceDigest(snapshot, {
  maxBytes: 2_048,
  fullSnapshotTool: 'my_app_read_surface',
});

const prompt = `${lead}\n${digest.text}`;
```

The digest is **deterministic** (the same snapshot renders to the same bytes — no clock
is ever read, so an observation's age is the distance between two timestamps that are
both in the snapshot), **complete** (every fact the snapshot declares is rendered; the
only omission is the byte budget's, and the digest says so), **bounded**, and **fenced**.

## Development

```
npm install
npm run build   # tsc, then copy the schema next to the compiled validator
npm test
```

The schema is read from disk at runtime rather than restated in code: it lives with the
specification and the build copies it beside the compiled output, so there is one file and
no drift. `surfaceSchemaFile()` looks in both places, which is why a source checkout works
before a build.

Two properties of this package are load-bearing and easy to break by accident:

- `surface-digest.ts` and `surface-semantics.ts` import nothing but erased types. Compiled
  to CommonJS they emit zero `require()` calls, which is what lets a browser load them
  directly as classic scripts behind a two-line `exports` shim. Keep them free of runtime
  imports — `test/surface-emit.spec.ts` compiles both and runs them in a context with no
  module system, so breaking this fails here rather than in a consumer's browser.
- The compile target is CommonJS for the same reason.

## Licence

Apache-2.0. See [LICENSE](LICENSE).
