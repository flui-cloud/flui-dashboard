import * as _angular_core from '@angular/core';
import { OnDestroy, ElementRef } from '@angular/core';
import * as i1 from '@dawit-io/spartan-sidebar-core';
import { BrnSidebarService, BrnSidebarGroupDirective, BrnSidebarComponent } from '@dawit-io/spartan-sidebar-core';
import { ClassValue } from 'clsx';
import { Router } from '@angular/router';

declare class HlmSidebarBrandComponent {
    protected readonly _sidebarService: BrnSidebarService;
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    protected readonly _computedClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarBrandComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarBrandComponent, "hlm-sidebar-brand", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; }, {}, never, ["ng-icon", "*"], true, never>;
}

declare class HlmSidebarContentHeaderComponent {
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    readonly withBorder: _angular_core.InputSignal<boolean>;
    protected readonly _computedClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarContentHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarContentHeaderComponent, "hlm-sidebar-content-header", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; "withBorder": { "alias": "withBorder"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class HlmSidebarFooterComponent {
    protected readonly _sidebarService: BrnSidebarService;
    readonly clicked: _angular_core.OutputEmitterRef<void>;
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    readonly title: _angular_core.InputSignal<string>;
    readonly subtitle: _angular_core.InputSignal<string>;
    protected readonly _computedClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarFooterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarFooterComponent, "hlm-sidebar-footer", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": true; "isSignal": true; }; }, { "clicked": "clicked"; }, never, ["ng-icon"], true, never>;
}

interface SidebarNavItem {
    label: string;
    link: string;
    routerLinkActive?: string;
    icon?: string;
}
declare class HlmSidebarGroupTooltipComponent {
    readonly groupLabel: _angular_core.InputSignal<string>;
    readonly items: _angular_core.InputSignal<SidebarNavItem[]>;
    readonly navigate: _angular_core.OutputEmitterRef<string>;
    onNavigate(link: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarGroupTooltipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarGroupTooltipComponent, "hlm-sidebar-group-tooltip", never, { "groupLabel": { "alias": "groupLabel"; "required": true; "isSignal": true; }; "items": { "alias": "items"; "required": true; "isSignal": true; }; }, { "navigate": "navigate"; }, never, never, true, never>;
}

declare class HlmSidebarGroupContentComponent {
    protected readonly _group: BrnSidebarGroupDirective;
    protected readonly _sidebarService: BrnSidebarService;
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    readonly items: _angular_core.InputSignal<SidebarNavItem[]>;
    protected readonly _computedClass: _angular_core.Signal<string>;
    onNavigate(link: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarGroupContentComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarGroupContentComponent, "hlm-sidebar-group-content", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class HlmSidebarGroupLabelComponent implements OnDestroy {
    labelContainer: ElementRef;
    protected readonly _sidebarService: BrnSidebarService;
    protected readonly _group: BrnSidebarGroupDirective;
    protected readonly _router: Router;
    readonly label: _angular_core.InputSignal<string>;
    readonly items: _angular_core.InputSignal<SidebarNavItem[]>;
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    private readonly _overlay;
    private overlayRef;
    private showTooltipSignal;
    private isMouseOverTrigger;
    private isMouseOverTooltip;
    constructor();
    ngOnDestroy(): void;
    protected readonly _computedClass: _angular_core.Signal<string>;
    handleMouseEnter(): void;
    handleMouseLeave(): void;
    private createTooltip;
    private maybeRemoveTooltip;
    private removeTooltip;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarGroupLabelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarGroupLabelComponent, "hlm-sidebar-group-label", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; }, {}, never, ["ng-icon"], true, [{ directive: typeof i1.BrnSidebarGroupLabelDirective; inputs: {}; outputs: {}; }]>;
}

declare class HlmSidebarGroupComponent {
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    readonly items: _angular_core.InputSignal<SidebarNavItem[]>;
    protected readonly _computedClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarGroupComponent, "hlm-sidebar-group", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.BrnSidebarGroupDirective; inputs: {}; outputs: {}; }]>;
}

declare class HlmSidebarHeaderComponent {
    private readonly _sidebarService;
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    protected readonly _computedClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarHeaderComponent, "hlm-sidebar-header", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class HlmSidebarInsetComponent {
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    protected readonly _computedClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarInsetComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarInsetComponent, "hlm-sidebar-inset", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class HlmSidebarItemComponent implements OnDestroy {
    protected readonly _sidebarService: BrnSidebarService;
    protected readonly _computedClass: _angular_core.Signal<string>;
    readonly clicked: _angular_core.OutputEmitterRef<void>;
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    readonly label: _angular_core.InputSignal<string>;
    readonly link: _angular_core.InputSignal<string | any[]>;
    readonly linkActive: _angular_core.InputSignal<string>;
    iconContainer: ElementRef;
    private overlayRef;
    private overlay;
    private showTooltipSignal;
    constructor();
    handleMouseEnter(): void;
    handleMouseLeave(): void;
    private createTooltip;
    private removeTooltip;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarItemComponent, "hlm-sidebar-item", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "link": { "alias": "link"; "required": false; "isSignal": true; }; "linkActive": { "alias": "linkActive"; "required": false; "isSignal": true; }; }, { "clicked": "clicked"; }, never, ["ng-icon"], true, never>;
}

declare class HlmSidebarNavComponent {
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    protected readonly _computedClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarNavComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarNavComponent, "hlm-sidebar-nav", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class HlmSidebarSectionTitleDirective {
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    protected readonly sidebarService: BrnSidebarService;
    protected readonly _computedClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarSectionTitleDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<HlmSidebarSectionTitleDirective, "[hlmSidebarSectionTitle]", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class HlmSidebarTriggerComponent {
    protected readonly _sidebarService: BrnSidebarService;
    protected readonly _computedClass: _angular_core.Signal<string>;
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarTriggerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarTriggerComponent, "hlm-sidebar-trigger", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class HlmSidebarComponent extends BrnSidebarComponent {
    constructor();
    protected get sidebarService(): i1.BrnSidebarService;
    protected readonly _computedClass: _angular_core.Signal<string>;
    readonly userClass: _angular_core.InputSignal<ClassValue>;
    protected readonly _computedScrollbarColor: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HlmSidebarComponent, "hlm-sidebar", never, { "userClass": { "alias": "userClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare const HlmSidebarImports: readonly [typeof HlmSidebarComponent, typeof HlmSidebarTriggerComponent, typeof HlmSidebarHeaderComponent, typeof HlmSidebarBrandComponent, typeof HlmSidebarNavComponent, typeof HlmSidebarItemComponent, typeof HlmSidebarContentHeaderComponent, typeof HlmSidebarGroupComponent, typeof HlmSidebarGroupLabelComponent, typeof HlmSidebarGroupContentComponent, typeof HlmSidebarFooterComponent, typeof HlmSidebarInsetComponent, typeof HlmSidebarSectionTitleDirective, typeof HlmSidebarGroupTooltipComponent];
declare class HlmSidebarModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HlmSidebarModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<HlmSidebarModule, never, [typeof HlmSidebarComponent, typeof HlmSidebarTriggerComponent, typeof HlmSidebarHeaderComponent, typeof HlmSidebarBrandComponent, typeof HlmSidebarNavComponent, typeof HlmSidebarItemComponent, typeof HlmSidebarContentHeaderComponent, typeof HlmSidebarGroupComponent, typeof HlmSidebarGroupLabelComponent, typeof HlmSidebarGroupContentComponent, typeof HlmSidebarFooterComponent, typeof HlmSidebarInsetComponent, typeof HlmSidebarSectionTitleDirective, typeof HlmSidebarGroupTooltipComponent], [typeof HlmSidebarComponent, typeof HlmSidebarTriggerComponent, typeof HlmSidebarHeaderComponent, typeof HlmSidebarBrandComponent, typeof HlmSidebarNavComponent, typeof HlmSidebarItemComponent, typeof HlmSidebarContentHeaderComponent, typeof HlmSidebarGroupComponent, typeof HlmSidebarGroupLabelComponent, typeof HlmSidebarGroupContentComponent, typeof HlmSidebarFooterComponent, typeof HlmSidebarInsetComponent, typeof HlmSidebarSectionTitleDirective, typeof HlmSidebarGroupTooltipComponent]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<HlmSidebarModule>;
}

export { HlmSidebarBrandComponent, HlmSidebarComponent, HlmSidebarContentHeaderComponent, HlmSidebarFooterComponent, HlmSidebarGroupComponent, HlmSidebarGroupContentComponent, HlmSidebarGroupLabelComponent, HlmSidebarGroupTooltipComponent, HlmSidebarHeaderComponent, HlmSidebarImports, HlmSidebarInsetComponent, HlmSidebarItemComponent, HlmSidebarModule, HlmSidebarNavComponent, HlmSidebarSectionTitleDirective, HlmSidebarTriggerComponent };
export type { SidebarNavItem };
