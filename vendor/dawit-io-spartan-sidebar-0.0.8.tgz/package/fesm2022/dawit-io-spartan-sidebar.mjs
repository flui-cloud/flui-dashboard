import * as i0 from '@angular/core';
import { inject, input, computed, ChangeDetectionStrategy, Component, output, signal, effect, ViewChild, Directive, NgModule } from '@angular/core';
import * as i1$1 from '@dawit-io/spartan-sidebar-core';
import { BrnSidebarService, BrnSidebarGroupDirective, BrnSidebarGroupLabelDirective, BrnSidebarTriggerDirective, BrnSidebarComponent } from '@dawit-io/spartan-sidebar-core';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/router';
import { RouterModule, Router } from '@angular/router';
import { Overlay, OverlayModule } from '@angular/cdk/overlay';
import { ComponentPortal, PortalModule } from '@angular/cdk/portal';
import { NgIcon, provideIcons, NgIconComponent } from '@ng-icons/core';
import { lucideChevronDown, lucidePanelRight, lucidePanelLeft } from '@ng-icons/lucide';

function hlm(...inputs) {
    return twMerge(clsx(inputs));
}

class HlmSidebarBrandComponent {
    _sidebarService = inject(BrnSidebarService);
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    _computedClass = computed(() => hlm('flex items-center min-w-0', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarBrandComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.4", type: HlmSidebarBrandComponent, isStandalone: true, selector: "hlm-sidebar-brand", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "_computedClass()" } }, ngImport: i0, template: `
		<div class="flex w-full items-center" [class.justify-center]="!_sidebarService.isExpanded()">
			<div class="flex items-center" [class.gap-2]="_sidebarService.isExpanded()">
				<div class="bg-primary text-primary-foreground flex h-8 w-8 items-center justify-center rounded-md">
					<ng-content select="ng-icon" />
				</div>
				<span class="truncate text-lg font-semibold">
					<ng-content />
				</span>
			</div>
		</div>
	`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarBrandComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-brand',
                    standalone: true,
                    host: {
                        '[class]': '_computedClass()',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
		<div class="flex w-full items-center" [class.justify-center]="!_sidebarService.isExpanded()">
			<div class="flex items-center" [class.gap-2]="_sidebarService.isExpanded()">
				<div class="bg-primary text-primary-foreground flex h-8 w-8 items-center justify-center rounded-md">
					<ng-content select="ng-icon" />
				</div>
				<span class="truncate text-lg font-semibold">
					<ng-content />
				</span>
			</div>
		</div>
	`,
                }]
        }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }] } });

class HlmSidebarContentHeaderComponent {
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    withBorder = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "withBorder" }] : /* istanbul ignore next */ []));
    _computedClass = computed(() => hlm('flex items-center py-2 px-4 bg-background', this.withBorder() && 'border-b', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarContentHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.4", type: HlmSidebarContentHeaderComponent, isStandalone: true, selector: "hlm-sidebar-content-header", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null }, withBorder: { classPropertyName: "withBorder", publicName: "withBorder", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "_computedClass()" } }, ngImport: i0, template: `
		<ng-content />
	`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarContentHeaderComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-content-header',
                    standalone: true,
                    host: {
                        '[class]': '_computedClass()',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
		<ng-content />
	`,
                }]
        }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }], withBorder: [{ type: i0.Input, args: [{ isSignal: true, alias: "withBorder", required: false }] }] } });

class HlmSidebarFooterComponent {
    _sidebarService = inject(BrnSidebarService);
    clicked = output();
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    title = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    subtitle = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "subtitle" }] : /* istanbul ignore next */ []));
    _computedClass = computed(() => hlm('block mt-auto', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarFooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.4", type: HlmSidebarFooterComponent, isStandalone: true, selector: "hlm-sidebar-footer", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, subtitle: { classPropertyName: "subtitle", publicName: "subtitle", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { clicked: "clicked" }, host: { properties: { "class": "_computedClass()" } }, ngImport: i0, template: `
		<button
			[ngClass]="{ 'px-3': _sidebarService.isExpanded(), 'px-2': !_sidebarService.isExpanded() }"
			class="border-border group relative h-12 w-full border-t"
			(click)="clicked.emit()"
		>
			<div
				class="flex w-full items-center"
				[class.justify-start]="_sidebarService.isExpanded()"
				[class.justify-center]="!_sidebarService.isExpanded()"
			>
				<div
					class="border-border bg-muted text-muted-foreground flex h-9 w-9 items-center justify-center rounded-md border transition-transform duration-200 ease-in-out group-hover:scale-110"
				>
					<ng-content select="ng-icon" />
				</div>

				@if (_sidebarService.isExpanded()) {
					<div class="ml-3 flex min-w-0 flex-col">
						<span class="text-foreground truncate text-sm font-medium">{{ title() }}</span>
						<span class="text-muted-foreground truncate text-xs">{{ subtitle() }}</span>
					</div>
				} @else {
					<div
						class="bg-popover text-popover-foreground invisible absolute bottom-full left-full z-50 mb-2 ml-2 rounded-md px-2 py-1 text-xs opacity-0 transition-opacity group-hover:visible group-hover:opacity-100"
					>
						{{ title() }}
					</div>
				}
			</div>
		</button>
	`, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarFooterComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-footer',
                    standalone: true,
                    imports: [CommonModule],
                    host: {
                        '[class]': '_computedClass()',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
		<button
			[ngClass]="{ 'px-3': _sidebarService.isExpanded(), 'px-2': !_sidebarService.isExpanded() }"
			class="border-border group relative h-12 w-full border-t"
			(click)="clicked.emit()"
		>
			<div
				class="flex w-full items-center"
				[class.justify-start]="_sidebarService.isExpanded()"
				[class.justify-center]="!_sidebarService.isExpanded()"
			>
				<div
					class="border-border bg-muted text-muted-foreground flex h-9 w-9 items-center justify-center rounded-md border transition-transform duration-200 ease-in-out group-hover:scale-110"
				>
					<ng-content select="ng-icon" />
				</div>

				@if (_sidebarService.isExpanded()) {
					<div class="ml-3 flex min-w-0 flex-col">
						<span class="text-foreground truncate text-sm font-medium">{{ title() }}</span>
						<span class="text-muted-foreground truncate text-xs">{{ subtitle() }}</span>
					</div>
				} @else {
					<div
						class="bg-popover text-popover-foreground invisible absolute bottom-full left-full z-50 mb-2 ml-2 rounded-md px-2 py-1 text-xs opacity-0 transition-opacity group-hover:visible group-hover:opacity-100"
					>
						{{ title() }}
					</div>
				}
			</div>
		</button>
	`,
                }]
        }], propDecorators: { clicked: [{ type: i0.Output, args: ["clicked"] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], subtitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "subtitle", required: true }] }] } });

class HlmSidebarTooltipComponent {
    text = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarTooltipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.4", type: HlmSidebarTooltipComponent, isStandalone: true, selector: "hlm-sidebar-tooltip", ngImport: i0, template: `<div class="bg-white border border-gray-200 rounded-md shadow-lg p-2 min-w-max text-xs whitespace-nowrap">
    {{ text() }}
  </div>`, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }], changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarTooltipComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-tooltip',
                    template: `<div class="bg-white border border-gray-200 rounded-md shadow-lg p-2 min-w-max text-xs whitespace-nowrap">
    {{ text() }}
  </div>`,
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.Eager,
                    imports: [CommonModule]
                }]
        }] });

class HlmSidebarItemComponent {
    _sidebarService = inject(BrnSidebarService);
    _computedClass = computed(() => hlm('block', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    clicked = output();
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    label = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    link = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "link" }] : /* istanbul ignore next */ []));
    linkActive = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "linkActive" }] : /* istanbul ignore next */ []));
    iconContainer;
    overlayRef = null;
    overlay = inject(Overlay);
    showTooltipSignal = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTooltipSignal" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const shouldShow = this.showTooltipSignal();
            if (shouldShow && !this._sidebarService.isExpanded()) {
                this.createTooltip();
            }
            else {
                this.removeTooltip();
            }
        });
    }
    handleMouseEnter() {
        this.showTooltipSignal.set(true);
    }
    handleMouseLeave() {
        this.showTooltipSignal.set(false);
    }
    createTooltip() {
        if (!this.iconContainer) {
            return;
        }
        const positionStrategy = this.overlay
            .position()
            .flexibleConnectedTo(this.iconContainer)
            .withPositions([
            {
                originX: 'end',
                originY: 'center',
                overlayX: 'start',
                overlayY: 'center',
                offsetX: 8
            }
        ]);
        this.overlayRef = this.overlay.create({
            positionStrategy,
            scrollStrategy: this.overlay.scrollStrategies.close()
        });
        const tooltipPortal = new ComponentPortal(HlmSidebarTooltipComponent);
        const tooltipRef = this.overlayRef.attach(tooltipPortal);
        tooltipRef.instance.text.set(this.label());
    }
    removeTooltip() {
        if (this.overlayRef) {
            this.overlayRef.dispose();
            this.overlayRef = null;
        }
    }
    ngOnDestroy() {
        this.removeTooltip();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.4", type: HlmSidebarItemComponent, isStandalone: true, selector: "hlm-sidebar-item", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, link: { classPropertyName: "link", publicName: "link", isSignal: true, isRequired: false, transformFunction: null }, linkActive: { classPropertyName: "linkActive", publicName: "linkActive", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { clicked: "clicked" }, host: { properties: { "class": "_computedClass()" } }, viewQueries: [{ propertyName: "iconContainer", first: true, predicate: ["iconContainer"], descendants: true }], ngImport: i0, template: `
    <a
      [attr.href]="link() ? null : 'javascript:void(0)'"
      [routerLink]="link() || null"
      [routerLinkActive]="linkActive()"
      [ngClass]="{ 'pl-2': _sidebarService.isExpanded() }"
      class="group relative h-9 w-full flex cursor-pointer"
      (click)="clicked.emit()"
    >
      <div
        class="flex w-full items-center"
        [class.justify-start]="_sidebarService.isExpanded()"
        [class.justify-center]="!_sidebarService.isExpanded()"
      >
        <div
          #iconContainer
          class="transition-transform duration-200 ease-in-out group-hover:scale-110 relative"
          (mouseenter)="handleMouseEnter()"
          (mouseleave)="handleMouseLeave()"
        >
          <ng-content select="ng-icon" />
        </div>
        <span class="text-foreground ml-2 overflow-hidden truncate">{{
          label()
        }}</span>
      </div>
    </a>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "ngmodule", type: PortalModule }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "directive", type: i2.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }], changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarItemComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-item',
                    standalone: true,
                    imports: [CommonModule, OverlayModule, PortalModule, RouterModule],
                    host: {
                        '[class]': '_computedClass()',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
    <a
      [attr.href]="link() ? null : 'javascript:void(0)'"
      [routerLink]="link() || null"
      [routerLinkActive]="linkActive()"
      [ngClass]="{ 'pl-2': _sidebarService.isExpanded() }"
      class="group relative h-9 w-full flex cursor-pointer"
      (click)="clicked.emit()"
    >
      <div
        class="flex w-full items-center"
        [class.justify-start]="_sidebarService.isExpanded()"
        [class.justify-center]="!_sidebarService.isExpanded()"
      >
        <div
          #iconContainer
          class="transition-transform duration-200 ease-in-out group-hover:scale-110 relative"
          (mouseenter)="handleMouseEnter()"
          (mouseleave)="handleMouseLeave()"
        >
          <ng-content select="ng-icon" />
        </div>
        <span class="text-foreground ml-2 overflow-hidden truncate">{{
          label()
        }}</span>
      </div>
    </a>
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { clicked: [{ type: i0.Output, args: ["clicked"] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], link: [{ type: i0.Input, args: [{ isSignal: true, alias: "link", required: false }] }], linkActive: [{ type: i0.Input, args: [{ isSignal: true, alias: "linkActive", required: false }] }], iconContainer: [{
                type: ViewChild,
                args: ['iconContainer']
            }] } });

class HlmSidebarGroupContentComponent {
    _group = inject(BrnSidebarGroupDirective);
    _sidebarService = inject(BrnSidebarService);
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    items = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    _computedClass = computed(() => hlm('data-[state=collapsed]:hidden', 'transition-all duration-200 ease-in-out', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    onNavigate(link) {
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarGroupContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.4", type: HlmSidebarGroupContentComponent, isStandalone: true, selector: "hlm-sidebar-group-content", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "_computedClass()", "attr.data-state": "_sidebarService.isExpanded() ? \"expanded\" : \"collapsed\"", "attr.data-group-state": "_group.isExpanded() ? \"expanded\" : \"collapsed\"" } }, ngImport: i0, template: `
    <div
      class="overflow-hidden transition-all duration-200"
      [class.opacity-100]="_group.isExpanded()"
      [class.opacity-0]="!_group.isExpanded()"
      [class.max-h-[1000px]="_group.isExpanded()"
      [class.max-h-0]="!_group.isExpanded()"
    >
      <div class="relative pl-6">
        <div class="bg-border absolute bottom-0 left-0 top-0 ml-2.5 w-px"></div>
        @if (items().length > 0) { @for (item of items(); track item.link) {
        <hlm-sidebar-item
          [label]="item.label"
          [link]="item.link"
          [linkActive]="item.routerLinkActive || ''"
          (clicked)="onNavigate(item.link)"
        >
          @if (item.icon) {
          <ng-icon
            [name]="item.icon"
            class="h-4 w-4 text-muted-foreground"
          ></ng-icon>
          }
        </hlm-sidebar-item>
        } } @else {
        <ng-content />
        }
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: HlmSidebarItemComponent, selector: "hlm-sidebar-item", inputs: ["userClass", "label", "link", "linkActive"], outputs: ["clicked"] }, { kind: "component", type: NgIcon, selector: "ng-icon", inputs: ["name", "svg", "size", "strokeWidth", "color"] }], changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarGroupContentComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-group-content',
                    standalone: true,
                    imports: [CommonModule, HlmSidebarItemComponent, NgIcon],
                    host: {
                        '[class]': '_computedClass()',
                        '[attr.data-state]': '_sidebarService.isExpanded() ? "expanded" : "collapsed"',
                        '[attr.data-group-state]': '_group.isExpanded() ? "expanded" : "collapsed"',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
    <div
      class="overflow-hidden transition-all duration-200"
      [class.opacity-100]="_group.isExpanded()"
      [class.opacity-0]="!_group.isExpanded()"
      [class.max-h-[1000px]="_group.isExpanded()"
      [class.max-h-0]="!_group.isExpanded()"
    >
      <div class="relative pl-6">
        <div class="bg-border absolute bottom-0 left-0 top-0 ml-2.5 w-px"></div>
        @if (items().length > 0) { @for (item of items(); track item.link) {
        <hlm-sidebar-item
          [label]="item.label"
          [link]="item.link"
          [linkActive]="item.routerLinkActive || ''"
          (clicked)="onNavigate(item.link)"
        >
          @if (item.icon) {
          <ng-icon
            [name]="item.icon"
            class="h-4 w-4 text-muted-foreground"
          ></ng-icon>
          }
        </hlm-sidebar-item>
        } } @else {
        <ng-content />
        }
      </div>
    </div>
  `,
                }]
        }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }] } });

class HlmSidebarGroupTooltipComponent {
    groupLabel = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "groupLabel" }] : /* istanbul ignore next */ []));
    items = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    navigate = output();
    onNavigate(link) {
        this.navigate.emit(link);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarGroupTooltipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.4", type: HlmSidebarGroupTooltipComponent, isStandalone: true, selector: "hlm-sidebar-group-tooltip", inputs: { groupLabel: { classPropertyName: "groupLabel", publicName: "groupLabel", isSignal: true, isRequired: true, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { navigate: "navigate" }, ngImport: i0, template: `
    <div
      class="bg-popover text-popover-foreground rounded-md border border-border shadow-md z-50"
    >
      <div class="flex flex-col py-2">
        @for (item of items(); track item.link) {
        <a
          [routerLink]="item.link"
          [routerLinkActive]="item.routerLinkActive || ''"
          class="text-sm text-center hover:bg-accent hover:text-accent-foreground px-4 py-2 cursor-pointer"
          (click)="onNavigate(item.link)"
        >
          {{ item.label }}
        </a>
        }
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "directive", type: i2.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }], changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarGroupTooltipComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-group-tooltip',
                    standalone: true,
                    imports: [CommonModule, RouterModule],
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
    <div
      class="bg-popover text-popover-foreground rounded-md border border-border shadow-md z-50"
    >
      <div class="flex flex-col py-2">
        @for (item of items(); track item.link) {
        <a
          [routerLink]="item.link"
          [routerLinkActive]="item.routerLinkActive || ''"
          class="text-sm text-center hover:bg-accent hover:text-accent-foreground px-4 py-2 cursor-pointer"
          (click)="onNavigate(item.link)"
        >
          {{ item.label }}
        </a>
        }
      </div>
    </div>
  `,
                }]
        }], propDecorators: { groupLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "groupLabel", required: true }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }], navigate: [{ type: i0.Output, args: ["navigate"] }] } });

class HlmSidebarGroupLabelComponent {
    labelContainer;
    _sidebarService = inject(BrnSidebarService);
    _group = inject(BrnSidebarGroupDirective);
    _router = inject(Router);
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    items = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    _overlay = inject(Overlay);
    overlayRef = null;
    showTooltipSignal = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTooltipSignal" }] : /* istanbul ignore next */ []));
    isMouseOverTrigger = false;
    isMouseOverTooltip = false;
    constructor() {
        effect(() => {
            const shouldShow = this.showTooltipSignal() && this.items().length > 0;
            if (shouldShow && !this._sidebarService.isExpanded()) {
                this.createTooltip();
            }
            else {
                this.removeTooltip();
            }
        });
    }
    ngOnDestroy() {
        this.removeTooltip();
    }
    _computedClass = computed(() => hlm('flex items-center w-full p-2 rounded-md text-foreground', 'hover:bg-accent hover:text-accent-foreground', 'transition-colors', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    handleMouseEnter() {
        this.isMouseOverTrigger = true;
        this.showTooltipSignal.set(true);
    }
    handleMouseLeave() {
        this.isMouseOverTrigger = false;
        this.maybeRemoveTooltip();
    }
    createTooltip() {
        if (!this.labelContainer) {
            return;
        }
        const positionStrategy = this._overlay
            .position()
            .flexibleConnectedTo(this.labelContainer)
            .withPositions([
            {
                originX: 'end',
                originY: 'center',
                overlayX: 'start',
                overlayY: 'center',
                offsetX: 8,
            },
        ]);
        this.overlayRef = this._overlay.create({
            positionStrategy,
            scrollStrategy: this._overlay.scrollStrategies.reposition(),
            hasBackdrop: false,
        });
        const tooltipPortal = new ComponentPortal(HlmSidebarGroupTooltipComponent);
        const tooltipRef = this.overlayRef.attach(tooltipPortal);
        tooltipRef.setInput('groupLabel', this.label());
        tooltipRef.setInput('items', this.items());
        tooltipRef.instance.navigate.subscribe((link) => {
            if (link) {
                this._router.navigateByUrl(link);
            }
            this.removeTooltip();
        });
        const tooltipElement = this.overlayRef.overlayElement;
        tooltipElement.addEventListener('mouseenter', () => {
            this.isMouseOverTooltip = true;
        });
        tooltipElement.addEventListener('mouseleave', () => {
            this.isMouseOverTooltip = false;
            this.maybeRemoveTooltip();
        });
    }
    maybeRemoveTooltip() {
        setTimeout(() => {
            if (!this.isMouseOverTrigger && !this.isMouseOverTooltip) {
                this.removeTooltip();
            }
        }, 100);
    }
    removeTooltip() {
        if (this.overlayRef) {
            this.overlayRef.dispose();
            this.overlayRef = null;
        }
        this.showTooltipSignal.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarGroupLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.4", type: HlmSidebarGroupLabelComponent, isStandalone: true, selector: "hlm-sidebar-group-label", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "_group.toggleExpansion()" }, properties: { "class": "_computedClass()" } }, providers: [provideIcons({ lucideChevronDown })], viewQueries: [{ propertyName: "labelContainer", first: true, predicate: ["labelContainer"], descendants: true }], hostDirectives: [{ directive: i1$1.BrnSidebarGroupLabelDirective }], ngImport: i0, template: `
    <div
      #labelContainer
      class="flex w-full cursor-pointer items-center"
      [class.justify-center]="!_sidebarService.isExpanded()"
      (mouseenter)="handleMouseEnter()"
      (mouseleave)="handleMouseLeave()"
    >
      <div
        class="transition-transform duration-200 ease-in-out hover:scale-110"
      >
        <ng-content select="ng-icon" />
      </div>
      <span class="text-foreground ml-2 overflow-hidden truncate">
        {{ label() }}
      </span>
      @if (_sidebarService.isExpanded()) {
      <ng-icon
        name="lucideChevronDown"
        class="text-foreground ml-auto h-4 w-4 transition-transform"
        [class.rotate-270]="!_group.isExpanded()"
      />
      }
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: NgIcon, selector: "ng-icon", inputs: ["name", "svg", "size", "strokeWidth", "color"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "ngmodule", type: PortalModule }], changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarGroupLabelComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-group-label',
                    standalone: true,
                    hostDirectives: [BrnSidebarGroupLabelDirective],
                    imports: [NgIcon, OverlayModule, PortalModule],
                    providers: [provideIcons({ lucideChevronDown })],
                    host: {
                        '[class]': '_computedClass()',
                        '(click)': '_group.toggleExpansion()',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
    <div
      #labelContainer
      class="flex w-full cursor-pointer items-center"
      [class.justify-center]="!_sidebarService.isExpanded()"
      (mouseenter)="handleMouseEnter()"
      (mouseleave)="handleMouseLeave()"
    >
      <div
        class="transition-transform duration-200 ease-in-out hover:scale-110"
      >
        <ng-content select="ng-icon" />
      </div>
      <span class="text-foreground ml-2 overflow-hidden truncate">
        {{ label() }}
      </span>
      @if (_sidebarService.isExpanded()) {
      <ng-icon
        name="lucideChevronDown"
        class="text-foreground ml-auto h-4 w-4 transition-transform"
        [class.rotate-270]="!_group.isExpanded()"
      />
      }
    </div>
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { labelContainer: [{
                type: ViewChild,
                args: ['labelContainer']
            }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }] } });

class HlmSidebarGroupComponent {
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    items = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    _computedClass = computed(() => hlm('flex flex-col gap-1', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.4", type: HlmSidebarGroupComponent, isStandalone: true, selector: "hlm-sidebar-group", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "_computedClass()" } }, hostDirectives: [{ directive: i1$1.BrnSidebarGroupDirective }], ngImport: i0, template: `
    <ng-content />
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarGroupComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-group',
                    standalone: true,
                    hostDirectives: [BrnSidebarGroupDirective],
                    host: {
                        '[class]': '_computedClass()',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
    <ng-content />
  `,
                }]
        }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }] } });

class HlmSidebarHeaderComponent {
    _sidebarService = inject(BrnSidebarService);
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    _computedClass = computed(() => hlm('flex items-center px-3 py-2 text-foreground', !this._sidebarService.isExpanded() ? 'justify-center' : '', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.4", type: HlmSidebarHeaderComponent, isStandalone: true, selector: "hlm-sidebar-header", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "_computedClass()" } }, ngImport: i0, template: `
		<ng-content />
	`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarHeaderComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-header',
                    standalone: true,
                    host: {
                        '[class]': '_computedClass()',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
		<ng-content />
	`,
                }]
        }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }] } });

class HlmSidebarInsetComponent {
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    _computedClass = computed(() => hlm('relative', '[&>*]:p-6', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarInsetComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.4", type: HlmSidebarInsetComponent, isStandalone: true, selector: "hlm-sidebar-inset", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "_computedClass()" } }, ngImport: i0, template: `
		<ng-content />
	`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarInsetComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-inset',
                    standalone: true,
                    template: `
		<ng-content />
	`,
                    changeDetection: ChangeDetectionStrategy.Eager,
                    host: {
                        '[class]': '_computedClass()',
                    },
                }]
        }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }] } });

class HlmSidebarNavComponent {
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    _computedClass = computed(() => hlm('flex flex-col gap-1 px-3', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarNavComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.4", type: HlmSidebarNavComponent, isStandalone: true, selector: "hlm-sidebar-nav", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "_computedClass()" } }, ngImport: i0, template: `
		<ng-content />
	`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarNavComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-nav',
                    standalone: true,
                    host: {
                        '[class]': '_computedClass()',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
		<ng-content />
	`,
                }]
        }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }] } });

class HlmSidebarSectionTitleDirective {
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    sidebarService = inject(BrnSidebarService);
    _computedClass = computed(() => hlm('text-xs font-semibold text-muted-foreground', 'px-2 mt-4 mb-2', 'data-[state=collapsed]:hidden', 'transition-opacity duration-200', 'data-[state=expanded]:opacity-100', 'data-[state=collapsed]:opacity-0', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarSectionTitleDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.4", type: HlmSidebarSectionTitleDirective, isStandalone: true, selector: "[hlmSidebarSectionTitle]", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "_computedClass()", "attr.data-state": "sidebarService.isExpanded() ? \"expanded\" : \"collapsed\"" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarSectionTitleDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[hlmSidebarSectionTitle]',
                    standalone: true,
                    host: {
                        '[class]': '_computedClass()',
                        '[attr.data-state]': 'sidebarService.isExpanded() ? "expanded" : "collapsed"',
                    },
                }]
        }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }] } });

class HlmSidebarTriggerComponent {
    _sidebarService = inject(BrnSidebarService);
    _computedClass = computed(() => hlm('inline-flex items-center justify-center rounded-sm hover:bg-accent hover:text-accent-foreground', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarTriggerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.4", type: HlmSidebarTriggerComponent, isStandalone: true, selector: "hlm-sidebar-trigger", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "_computedClass()" } }, providers: [
            provideIcons({
                lucidePanelLeft,
                lucidePanelRight,
            }),
        ], ngImport: i0, template: `
		<button brnSidebarTrigger class="inline-flex items-center justify-center">
			<ng-icon
				hlm
				[name]="_sidebarService.isExpanded() ? 'lucidePanelLeft' : 'lucidePanelRight'"
				class="text-foreground h-4 w-4"
			/>
		</button>
	`, isInline: true, dependencies: [{ kind: "directive", type: BrnSidebarTriggerDirective, selector: "[brnSidebarTrigger]" }, { kind: "component", type: NgIconComponent, selector: "ng-icon", inputs: ["name", "svg", "size", "strokeWidth", "color"] }], changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarTriggerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar-trigger',
                    standalone: true,
                    imports: [BrnSidebarTriggerDirective, NgIconComponent],
                    providers: [
                        provideIcons({
                            lucidePanelLeft,
                            lucidePanelRight,
                        }),
                    ],
                    host: {
                        '[class]': '_computedClass()',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
		<button brnSidebarTrigger class="inline-flex items-center justify-center">
			<ng-icon
				hlm
				[name]="_sidebarService.isExpanded() ? 'lucidePanelLeft' : 'lucidePanelRight'"
				class="text-foreground h-4 w-4"
			/>
		</button>
	`,
                }]
        }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }] } });

class HlmSidebarComponent extends BrnSidebarComponent {
    constructor() {
        super();
        console.log('HlmSidebarComponent constructor');
    }
    get sidebarService() {
        return this._sidebarService;
    }
    _computedClass = computed(() => hlm('relative z-40 flex h-full overflow-y-auto overflow-x-hidden flex-col flex-none border-r border-border bg-background transition-all duration-200', 
    // Variant styles
    this.sidebarService.variant() === 'sidebar' && ['sticky top-0 left-0', 'shrink-0'], this.sidebarService.variant() === 'floating' && ['absolute shadow-lg', 'bg-popover text-popover-foreground'], this.sidebarService.variant() === 'inset' && ['border rounded-lg m-4', 'bg-card text-card-foreground'], 
    // Collapsible mode styles
    this.sidebarService.collapsibleMode() === 'offcanvas' && [
        'w-64',
        'transform',
        'data-[state=collapsed]:-translate-x-full',
        'data-[state=collapsed]:absolute',
        'data-[state=collapsed]:opacity-0',
        'data-[state=expanded]:translate-x-0',
        'data-[state=expanded]:opacity-100',
    ], this.sidebarService.collapsibleMode() === 'icon' && [
        'w-64 data-[state=collapsed]:w-16',
        'data-[state=collapsed]:transition-[width]',
    ], this.sidebarService.collapsibleMode() === 'none' && ['w-64', 'transition-none'], 
    // Common styles for expanded/collapsed states
    'data-[state=expanded]:w-64', '[&_span]:data-[state=collapsed]:hidden [&_span]:data-[state=expanded]:inline', '[&_ng-icon]:data-[state=collapsed]:mx-auto', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedClass" }] : /* istanbul ignore next */ []));
    userClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "userClass" }] : /* istanbul ignore next */ []));
    _computedScrollbarColor = computed(() => 'var(--muted-foreground, hsl(var(--muted-foreground))) var(--border-color, hsl(var(--muted)))', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedScrollbarColor" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.4", type: HlmSidebarComponent, isStandalone: true, selector: "hlm-sidebar", inputs: { userClass: { classPropertyName: "userClass", publicName: "userClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "_computedClass()", "attr.data-state": "sidebarService.isExpanded() ? \"expanded\" : \"collapsed\"", "attr.data-collapsible": "sidebarService.collapsibleMode()", "style.scrollbar-width": "\"thin\"", "style.scrollbar-color": "_computedScrollbarColor()" } }, usesInheritance: true, ngImport: i0, template: `
		<div class="flex h-full flex-col">
			<ng-content />
		</div>
	`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.Eager });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'hlm-sidebar',
                    standalone: true,
                    host: {
                        '[class]': '_computedClass()',
                        '[attr.data-state]': 'sidebarService.isExpanded() ? "expanded" : "collapsed"',
                        '[attr.data-collapsible]': 'sidebarService.collapsibleMode()',
                        '[style.scrollbar-width]': '"thin"',
                        '[style.scrollbar-color]': '_computedScrollbarColor()',
                    },
                    changeDetection: ChangeDetectionStrategy.Eager,
                    template: `
		<div class="flex h-full flex-col">
			<ng-content />
		</div>
	`,
                }]
        }], ctorParameters: () => [], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "userClass", required: false }] }] } });

const HlmSidebarImports = [
    HlmSidebarComponent,
    HlmSidebarTriggerComponent,
    HlmSidebarHeaderComponent,
    HlmSidebarBrandComponent,
    HlmSidebarNavComponent,
    HlmSidebarItemComponent,
    HlmSidebarContentHeaderComponent,
    HlmSidebarGroupComponent,
    HlmSidebarGroupLabelComponent,
    HlmSidebarGroupContentComponent,
    HlmSidebarFooterComponent,
    HlmSidebarInsetComponent,
    HlmSidebarSectionTitleDirective,
    HlmSidebarGroupTooltipComponent,
];
class HlmSidebarModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarModule, imports: [HlmSidebarComponent,
            HlmSidebarTriggerComponent,
            HlmSidebarHeaderComponent,
            HlmSidebarBrandComponent,
            HlmSidebarNavComponent,
            HlmSidebarItemComponent,
            HlmSidebarContentHeaderComponent,
            HlmSidebarGroupComponent,
            HlmSidebarGroupLabelComponent,
            HlmSidebarGroupContentComponent,
            HlmSidebarFooterComponent,
            HlmSidebarInsetComponent,
            HlmSidebarSectionTitleDirective,
            HlmSidebarGroupTooltipComponent], exports: [HlmSidebarComponent,
            HlmSidebarTriggerComponent,
            HlmSidebarHeaderComponent,
            HlmSidebarBrandComponent,
            HlmSidebarNavComponent,
            HlmSidebarItemComponent,
            HlmSidebarContentHeaderComponent,
            HlmSidebarGroupComponent,
            HlmSidebarGroupLabelComponent,
            HlmSidebarGroupContentComponent,
            HlmSidebarFooterComponent,
            HlmSidebarInsetComponent,
            HlmSidebarSectionTitleDirective,
            HlmSidebarGroupTooltipComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarModule, imports: [HlmSidebarTriggerComponent,
            HlmSidebarItemComponent,
            HlmSidebarGroupLabelComponent,
            HlmSidebarGroupContentComponent,
            HlmSidebarFooterComponent,
            HlmSidebarGroupTooltipComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: HlmSidebarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [...HlmSidebarImports],
                    exports: [...HlmSidebarImports],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { HlmSidebarBrandComponent, HlmSidebarComponent, HlmSidebarContentHeaderComponent, HlmSidebarFooterComponent, HlmSidebarGroupComponent, HlmSidebarGroupContentComponent, HlmSidebarGroupLabelComponent, HlmSidebarGroupTooltipComponent, HlmSidebarHeaderComponent, HlmSidebarImports, HlmSidebarInsetComponent, HlmSidebarItemComponent, HlmSidebarModule, HlmSidebarNavComponent, HlmSidebarSectionTitleDirective, HlmSidebarTriggerComponent };
//# sourceMappingURL=dawit-io-spartan-sidebar.mjs.map
