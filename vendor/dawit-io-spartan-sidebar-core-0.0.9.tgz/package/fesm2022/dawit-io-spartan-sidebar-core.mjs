import * as i0 from '@angular/core';
import { signal, computed, Injectable, inject, ChangeDetectionStrategy, Component, Directive, HostBinding, Input, HostListener, effect, input, NgModule } from '@angular/core';

class BrnSidebarService {
    _state = signal({
        id: '',
        isExpanded: true,
        isCollapsible: true,
        isMobile: false,
        isOverlay: false,
        variant: 'sidebar',
        collapsibleMode: 'icon',
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_state" }] : /* istanbul ignore next */ []));
    id = computed(() => this._state().id, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    isExpanded = computed(() => this._state().isExpanded, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []));
    isCollapsible = computed(() => this._state().isCollapsible, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isCollapsible" }] : /* istanbul ignore next */ []));
    isMobile = computed(() => this._state().isMobile, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isMobile" }] : /* istanbul ignore next */ []));
    isOverlay = computed(() => this._state().isOverlay, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOverlay" }] : /* istanbul ignore next */ []));
    variant = computed(() => this._state().variant, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    collapsibleMode = computed(() => this._state().collapsibleMode, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapsibleMode" }] : /* istanbul ignore next */ []));
    constructor() {
        this.checkIfMobile();
        if (window) {
            const mediaQuery = window.matchMedia('(max-width: 768px)');
            this.handleMobileChange(mediaQuery);
            mediaQuery.addEventListener('change', (e) => {
                this.handleMobileChange(e);
            });
        }
    }
    toggle() {
        if (!this._state().isCollapsible)
            return;
        this._state.update((state) => ({
            ...state,
            isExpanded: !state.isExpanded,
        }));
    }
    setId(id) {
        this._state.update((state) => ({
            ...state,
            id,
        }));
    }
    setCollapsible(isCollapsible) {
        this._state.update((state) => ({
            ...state,
            isCollapsible,
        }));
    }
    setMobileState(isMobile) {
        this._state.update((state) => ({
            ...state,
            isMobile,
            collapsibleMode: isMobile ? 'offcanvas' : state.collapsibleMode,
            isOverlay: isMobile,
        }));
    }
    setVariant(variant) {
        this._state.update((state) => ({
            ...state,
            variant,
        }));
    }
    setCollapsibleMode(mode) {
        this._state.update((state) => ({
            ...state,
            collapsibleMode: mode,
        }));
    }
    setOverlayMode(isOverlay) {
        this._state.update((state) => ({
            ...state,
            isOverlay,
        }));
    }
    checkIfMobile() {
        if (typeof window !== 'undefined') {
            const isMobile = window.matchMedia('(max-width: 768px)').matches;
            this.setMobileState(isMobile);
            //if mobile close sidebar
            if (isMobile) {
                this._state.update((state) => ({
                    ...state,
                    isExpanded: false,
                }));
            }
        }
    }
    handleMobileChange(e) {
        const isMobile = e.matches;
        this.setMobileState(isMobile);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

class BrnSidebarFooterComponent {
    _sidebarService = inject(BrnSidebarService);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarFooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.4", type: BrnSidebarFooterComponent, isStandalone: true, selector: "brn-sidebar-footer", host: { attributes: { "role": "complementary" }, properties: { "class.collapsed": "!_sidebarService.isExpanded()", "attr.data-state": "_sidebarService.isExpanded() ? \"expanded\" : \"collapsed\"" }, classAttribute: "brn-sidebar-footer" }, ngImport: i0, template: `
		<ng-content />
	`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarFooterComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'brn-sidebar-footer',
                    standalone: true,
                    template: `
		<ng-content />
	`,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        '[class.collapsed]': '!_sidebarService.isExpanded()',
                        '[attr.data-state]': '_sidebarService.isExpanded() ? "expanded" : "collapsed"',
                        role: 'complementary',
                        class: 'brn-sidebar-footer',
                    },
                }]
        }] });

class BrnSidebarGroupDirective {
    _sidebarService = inject(BrnSidebarService);
    labelId = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labelId" }] : /* istanbul ignore next */ []));
    isExpanded = signal(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []));
    toggleExpansion() {
        this.isExpanded.update((value) => !value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarGroupDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.4", type: BrnSidebarGroupDirective, isStandalone: true, selector: "[brnSidebarGroup]", host: { attributes: { "role": "group" }, properties: { "attr.aria-labelledby": "labelId()", "attr.data-expanded": "_sidebarService.isExpanded()", "attr.data-group-expanded": "isExpanded()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarGroupDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSidebarGroup]',
                    standalone: true,
                    host: {
                        role: 'group',
                        '[attr.aria-labelledby]': 'labelId()',
                        '[attr.data-expanded]': '_sidebarService.isExpanded()',
                        '[attr.data-group-expanded]': 'isExpanded()',
                    },
                }]
        }] });

let nextId$1 = 0;
class BrnSidebarGroupLabelDirective {
    _id = `brn-sidebar-group-label-${nextId$1++}`;
    _group = inject(BrnSidebarGroupDirective);
    constructor() {
        this._group.labelId.set(this._id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarGroupLabelDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.4", type: BrnSidebarGroupLabelDirective, isStandalone: true, selector: "[brnSidebarGroupLabel]", host: { properties: { "id": "_id" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarGroupLabelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSidebarGroupLabel]',
                    standalone: true,
                    host: {
                        '[id]': '_id',
                    },
                }]
        }], ctorParameters: () => [] });

class BrnSidebarNavItemDirective {
    icon;
    class = 'brn-sidebar-nav-item';
    isActive;
    get ariaCurrentValue() {
        return this.isActive ? 'page' : undefined;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarNavItemDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.4", type: BrnSidebarNavItemDirective, isStandalone: true, selector: "[brnSidebarNavItem]", inputs: { icon: "icon", isActive: "isActive" }, host: { properties: { "class": "this.class", "class.active": "this.isActive", "attr.aria-current": "this.ariaCurrentValue" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarNavItemDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSidebarNavItem]',
                    standalone: true,
                }]
        }], propDecorators: { icon: [{
                type: Input
            }], class: [{
                type: HostBinding,
                args: ['class']
            }], isActive: [{
                type: HostBinding,
                args: ['class.active']
            }, {
                type: Input
            }], ariaCurrentValue: [{
                type: HostBinding,
                args: ['attr.aria-current']
            }] } });

class BrnSidebarNavDirective {
    role = 'navigation';
    tabindex = 0;
    ariaLabel = 'Sidebar Navigation';
    onKeyDown(_event) {
        // TODO: Implement keyboard navigation logic
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarNavDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.4", type: BrnSidebarNavDirective, isStandalone: true, selector: "[brnSidebarNav]", host: { listeners: { "keydown": "onKeyDown($event)" }, properties: { "attr.role": "this.role", "tabindex": "this.tabindex", "attr.aria-label": "this.ariaLabel" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarNavDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSidebarNav]',
                    standalone: true,
                }]
        }], propDecorators: { role: [{
                type: HostBinding,
                args: ['attr.role']
            }], tabindex: [{
                type: HostBinding,
                args: ['tabindex']
            }], ariaLabel: [{
                type: HostBinding,
                args: ['attr.aria-label']
            }], onKeyDown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

const STORAGE_KEY = 'brn-sidebar:pinned-ids';
function readStoredPinnedIds() {
    if (typeof localStorage === 'undefined')
        return [];
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw)
            return [];
        const parsed = JSON.parse(raw);
        return Array.isArray(parsed) ? parsed.filter((id) => typeof id === 'string') : [];
    }
    catch {
        return [];
    }
}
class BrnSidebarPinService {
    _pinnedIds = signal(readStoredPinnedIds(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_pinnedIds" }] : /* istanbul ignore next */ []));
    pinnedIds = computed(() => this._pinnedIds(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pinnedIds" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const ids = this._pinnedIds();
            if (typeof localStorage === 'undefined')
                return;
            try {
                localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
            }
            catch {
                return;
            }
        });
    }
    isPinned(id) {
        return this._pinnedIds().includes(id);
    }
    toggle(id) {
        this._pinnedIds.update((ids) => (ids.includes(id) ? ids.filter((existing) => existing !== id) : [...ids, id]));
    }
    reset() {
        this._pinnedIds.set([]);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarPinService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarPinService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarPinService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

class BrnSidebarSearchService {
    _query = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_query" }] : /* istanbul ignore next */ []));
    query = computed(() => this._query(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    setQuery(value) {
        this._query.set(value);
    }
    matches(item) {
        const query = this._query().trim().toLowerCase();
        if (!query)
            return true;
        if (item.label.toLowerCase().includes(query))
            return true;
        return (item.keywords ?? []).some((keyword) => keyword.toLowerCase().includes(query));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarSearchService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarSearchService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarSearchService, decorators: [{
            type: Injectable
        }] });

class BrnSidebarTriggerDirective {
    _sidebarService = inject(BrnSidebarService);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarTriggerDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.4", type: BrnSidebarTriggerDirective, isStandalone: true, selector: "[brnSidebarTrigger]", host: { attributes: { "role": "button", "type": "button" }, listeners: { "click": "_sidebarService.toggle()" }, properties: { "attr.aria-expanded": "_sidebarService.isExpanded()", "attr.aria-controls": "_sidebarService.id()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarTriggerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnSidebarTrigger]',
                    standalone: true,
                    host: {
                        '(click)': '_sidebarService.toggle()',
                        '[attr.aria-expanded]': '_sidebarService.isExpanded()',
                        '[attr.aria-controls]': '_sidebarService.id()',
                        role: 'button',
                        type: 'button',
                    },
                }]
        }] });

let nextId = 0;
class BrnSidebarComponent {
    constructor() {
        this._sidebarService.setId(`brn-sidebar-${nextId++}`);
        effect(() => {
            this._sidebarService.setCollapsible(this.isCollapsible());
            this._sidebarService.setOverlayMode(this.isOverlay());
            this._sidebarService.setVariant(this.variant());
            this._sidebarService.setCollapsibleMode(this.collapsibleMode());
        });
    }
    _sidebarService = inject(BrnSidebarService);
    isCollapsible = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isCollapsible" }] : /* istanbul ignore next */ []));
    isOverlay = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOverlay" }] : /* istanbul ignore next */ []));
    variant = input('sidebar', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    collapsibleMode = input('icon', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapsibleMode" }] : /* istanbul ignore next */ []));
    isExpanded = computed(() => this._sidebarService.isExpanded(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []));
    _computedCollapsible = computed(() => {
        this._sidebarService.setCollapsible(this.isCollapsible());
        return this.isCollapsible();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedCollapsible" }] : /* istanbul ignore next */ []));
    _computedOverlay = computed(() => {
        this._sidebarService.setOverlayMode(this.isOverlay());
        return this.isOverlay();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedOverlay" }] : /* istanbul ignore next */ []));
    _computedVariant = computed(() => {
        this._sidebarService.setVariant(this.variant());
        console.log('variant', this.variant());
        return this.variant();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedVariant" }] : /* istanbul ignore next */ []));
    _computedCollapsibleMode = computed(() => {
        this._sidebarService.setCollapsibleMode(this.collapsibleMode());
        return this.collapsibleMode();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_computedCollapsibleMode" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.4", type: BrnSidebarComponent, isStandalone: true, selector: "brn-sidebar", inputs: { isCollapsible: { classPropertyName: "isCollapsible", publicName: "isCollapsible", isSignal: true, isRequired: false, transformFunction: null }, isOverlay: { classPropertyName: "isOverlay", publicName: "isOverlay", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, collapsibleMode: { classPropertyName: "collapsibleMode", publicName: "collapsibleMode", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.collapsed": "!_sidebarService.isExpanded()", "id": "_sidebarService.id()", "class.brn-sidebar-desktop": "!_sidebarService.isMobile()", "class.brn-sidebar-overlay": "_sidebarService.isMobile() && isExpanded()", "attr.data-variant": "variant()", "attr.data-collapsible": "collapsibleMode()", "class.is-collapsible": "isCollapsible()", "class.is-overlay": "isOverlay()" } }, providers: [BrnSidebarService, BrnSidebarSearchService, BrnSidebarPinService], ngImport: i0, template: `
		<ng-content />
	`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'brn-sidebar',
                    standalone: true,
                    providers: [BrnSidebarService, BrnSidebarSearchService, BrnSidebarPinService],
                    template: `
		<ng-content />
	`,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        '[class.collapsed]': '!_sidebarService.isExpanded()',
                        '[id]': '_sidebarService.id()',
                        '[class.brn-sidebar-desktop]': '!_sidebarService.isMobile()',
                        '[class.brn-sidebar-overlay]': '_sidebarService.isMobile() && isExpanded()',
                        '[attr.data-variant]': 'variant()',
                        '[attr.data-collapsible]': 'collapsibleMode()',
                        '[class.is-collapsible]': 'isCollapsible()',
                        '[class.is-overlay]': 'isOverlay()',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { isCollapsible: [{ type: i0.Input, args: [{ isSignal: true, alias: "isCollapsible", required: false }] }], isOverlay: [{ type: i0.Input, args: [{ isSignal: true, alias: "isOverlay", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], collapsibleMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsibleMode", required: false }] }] } });

const BrnSidebarImports = [
    BrnSidebarComponent,
    BrnSidebarTriggerDirective,
    BrnSidebarGroupDirective,
    BrnSidebarGroupLabelDirective,
    BrnSidebarNavItemDirective,
    BrnSidebarNavDirective,
    BrnSidebarFooterComponent,
];
class BrnSidebarModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarModule, imports: [BrnSidebarComponent,
            BrnSidebarTriggerDirective,
            BrnSidebarGroupDirective,
            BrnSidebarGroupLabelDirective,
            BrnSidebarNavItemDirective,
            BrnSidebarNavDirective,
            BrnSidebarFooterComponent], exports: [BrnSidebarComponent,
            BrnSidebarTriggerDirective,
            BrnSidebarGroupDirective,
            BrnSidebarGroupLabelDirective,
            BrnSidebarNavItemDirective,
            BrnSidebarNavDirective,
            BrnSidebarFooterComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarModule, providers: [BrnSidebarService, BrnSidebarSearchService, BrnSidebarPinService] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.4", ngImport: i0, type: BrnSidebarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [...BrnSidebarImports],
                    exports: [...BrnSidebarImports],
                    providers: [BrnSidebarService, BrnSidebarSearchService, BrnSidebarPinService],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { BrnSidebarComponent, BrnSidebarFooterComponent, BrnSidebarGroupDirective, BrnSidebarGroupLabelDirective, BrnSidebarImports, BrnSidebarModule, BrnSidebarNavDirective, BrnSidebarNavItemDirective, BrnSidebarPinService, BrnSidebarSearchService, BrnSidebarService, BrnSidebarTriggerDirective };
//# sourceMappingURL=dawit-io-spartan-sidebar-core.mjs.map
