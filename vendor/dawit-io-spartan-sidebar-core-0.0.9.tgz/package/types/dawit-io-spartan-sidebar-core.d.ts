import * as i0 from '@angular/core';

type SidebarVariant = 'sidebar' | 'floating' | 'inset';
type CollapsibleMode = 'offcanvas' | 'icon' | 'none';
declare class BrnSidebarService {
    private readonly _state;
    readonly id: i0.Signal<string>;
    readonly isExpanded: i0.Signal<boolean>;
    readonly isCollapsible: i0.Signal<boolean>;
    readonly isMobile: i0.Signal<boolean>;
    readonly isOverlay: i0.Signal<boolean>;
    readonly variant: i0.Signal<SidebarVariant>;
    readonly collapsibleMode: i0.Signal<CollapsibleMode>;
    constructor();
    toggle(): void;
    setId(id: string): void;
    setCollapsible(isCollapsible: boolean): void;
    setMobileState(isMobile: boolean): void;
    setVariant(variant: SidebarVariant): void;
    setCollapsibleMode(mode: CollapsibleMode): void;
    setOverlayMode(isOverlay: boolean): void;
    private checkIfMobile;
    private handleMobileChange;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BrnSidebarService>;
}

declare class BrnSidebarFooterComponent {
    protected readonly _sidebarService: BrnSidebarService;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BrnSidebarFooterComponent, "brn-sidebar-footer", never, {}, {}, never, ["*"], true, never>;
}

declare class BrnSidebarGroupLabelDirective {
    readonly _id: string;
    private readonly _group;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarGroupLabelDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnSidebarGroupLabelDirective, "[brnSidebarGroupLabel]", never, {}, {}, never, never, true, never>;
}

declare class BrnSidebarGroupDirective {
    protected readonly _sidebarService: BrnSidebarService;
    readonly labelId: i0.WritableSignal<string>;
    readonly isExpanded: i0.WritableSignal<boolean>;
    toggleExpansion(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarGroupDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnSidebarGroupDirective, "[brnSidebarGroup]", never, {}, {}, never, never, true, never>;
}

declare class BrnSidebarNavItemDirective {
    icon?: string;
    class: string;
    isActive: boolean | undefined;
    get ariaCurrentValue(): "page" | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarNavItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnSidebarNavItemDirective, "[brnSidebarNavItem]", never, { "icon": { "alias": "icon"; "required": false; }; "isActive": { "alias": "isActive"; "required": false; }; }, {}, never, never, true, never>;
}

declare class BrnSidebarNavDirective {
    role: string;
    tabindex: number;
    ariaLabel: string;
    onKeyDown(_event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarNavDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnSidebarNavDirective, "[brnSidebarNav]", never, {}, {}, never, never, true, never>;
}

declare class BrnSidebarTriggerDirective {
    protected readonly _sidebarService: BrnSidebarService;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarTriggerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnSidebarTriggerDirective, "[brnSidebarTrigger]", never, {}, {}, never, never, true, never>;
}

declare class BrnSidebarComponent {
    constructor();
    protected readonly _sidebarService: BrnSidebarService;
    readonly isCollapsible: i0.InputSignal<boolean>;
    readonly isOverlay: i0.InputSignal<boolean>;
    readonly variant: i0.InputSignal<SidebarVariant>;
    readonly collapsibleMode: i0.InputSignal<CollapsibleMode>;
    readonly isExpanded: i0.Signal<boolean>;
    protected readonly _computedCollapsible: i0.Signal<boolean>;
    protected readonly _computedOverlay: i0.Signal<boolean>;
    protected readonly _computedVariant: i0.Signal<SidebarVariant>;
    protected readonly _computedCollapsibleMode: i0.Signal<CollapsibleMode>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BrnSidebarComponent, "brn-sidebar", never, { "isCollapsible": { "alias": "isCollapsible"; "required": false; "isSignal": true; }; "isOverlay": { "alias": "isOverlay"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "collapsibleMode": { "alias": "collapsibleMode"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface SidebarNavItem {
    label: string;
    link: string;
    routerLinkActive?: string;
    icon?: string;
    id?: string;
    keywords?: string[];
}

declare class BrnSidebarPinService {
    private readonly _pinnedIds;
    readonly pinnedIds: i0.Signal<string[]>;
    constructor();
    isPinned(id: string): boolean;
    toggle(id: string): void;
    reset(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarPinService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BrnSidebarPinService>;
}

declare class BrnSidebarSearchService {
    private readonly _query;
    readonly query: i0.Signal<string>;
    setQuery(value: string): void;
    matches(item: {
        label: string;
        keywords?: string[];
    }): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarSearchService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BrnSidebarSearchService>;
}

declare const BrnSidebarImports: readonly [typeof BrnSidebarComponent, typeof BrnSidebarTriggerDirective, typeof BrnSidebarGroupDirective, typeof BrnSidebarGroupLabelDirective, typeof BrnSidebarNavItemDirective, typeof BrnSidebarNavDirective, typeof BrnSidebarFooterComponent];
declare class BrnSidebarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnSidebarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BrnSidebarModule, never, [typeof BrnSidebarComponent, typeof BrnSidebarTriggerDirective, typeof BrnSidebarGroupDirective, typeof BrnSidebarGroupLabelDirective, typeof BrnSidebarNavItemDirective, typeof BrnSidebarNavDirective, typeof BrnSidebarFooterComponent], [typeof BrnSidebarComponent, typeof BrnSidebarTriggerDirective, typeof BrnSidebarGroupDirective, typeof BrnSidebarGroupLabelDirective, typeof BrnSidebarNavItemDirective, typeof BrnSidebarNavDirective, typeof BrnSidebarFooterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BrnSidebarModule>;
}

export { BrnSidebarComponent, BrnSidebarFooterComponent, BrnSidebarGroupDirective, BrnSidebarGroupLabelDirective, BrnSidebarImports, BrnSidebarModule, BrnSidebarNavDirective, BrnSidebarNavItemDirective, BrnSidebarPinService, BrnSidebarSearchService, BrnSidebarService, BrnSidebarTriggerDirective };
export type { CollapsibleMode, SidebarNavItem, SidebarVariant };
